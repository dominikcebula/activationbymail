<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{activationbymail}prestashop>activationbymail_992878847a08f91cfda7c5b3b89813d4'] = 'Aktywacja konta przez e-mail';
$_MODULE['<{activationbymail}prestashop>activationbymail_dd3caf02ff796cdff2d6adaa6bcbbe17'] = 'Umożliwia walidację adresów e-mail przez przesyłanie linków aktywacyjnych';
$_MODULE['<{activationbymail}prestashop>activationbymail_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';

$_MODULE['<{activationbymail}prestashop>activation-success_8cf04a9734132302f96da8e113e80ce5'] = 'Strona główna';
$_MODULE['<{activationbymail}prestashop>activation-success_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';
$_MODULE['<{activationbymail}prestashop>activation-success_92b283c1b79b618634373dbedb5f933b'] = 'Twoje konto zostało pomyślnie aktywowane.';

$_MODULE['<{activationbymail}prestashop>activation-fail_8cf04a9734132302f96da8e113e80ce5'] = 'Strona główna';
$_MODULE['<{activationbymail}prestashop>activation-fail_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';
$_MODULE['<{activationbymail}prestashop>activation-fail_97687c6426225e27be5accfcf9b83c78'] = 'Wystąpił problem z aktywacją twojego konta, proszę skontaktować się z obsługą sklepu w celu rozwiązania problemu.';

$_MODULE['<{activationbymail}prestashop>info_8cf04a9734132302f96da8e113e80ce5'] = 'Strona główna';
$_MODULE['<{activationbymail}prestashop>info_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';
$_MODULE['<{activationbymail}prestashop>info_6873d17dfc95b69866d59374fe666355'] = 'Twoje konto zostało już utworzone, musisz je jeszcze aktywować, na twój e-mail został wysłany link aktywacyjny, po jego kliknięciu konto zostanie aktywowane.';
