<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{activationbymail}prestashop>activationbymail_992878847a08f91cfda7c5b3b89813d4'] = 'Aktywacja konta przez e-mail';
$_MODULE['<{activationbymail}prestashop>activationbymail_dd3caf02ff796cdff2d6adaa6bcbbe17'] = 'Umożliwia walidację adresów e-mail przez przesyłanie linków aktywacyjnych';
$_MODULE['<{activationbymail}prestashop>activationbymail_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';
$_MODULE['<{activationbymail}prestashop>info_8cf04a9734132302f96da8e113e80ce5'] = 'Strona główna';
$_MODULE['<{activationbymail}prestashop>info_ef5872ccb6ea77c26a046f51371a6043'] = 'Aktywacja konta';
$_MODULE['<{activationbymail}prestashop>info_6873d17dfc95b69866d59374fe666355'] = 'Twoje konto zostało już utworzone, musisz je jeszcze aktywować, na twój e-mail został wysłany link aktywacyjny, po jego kliknięciu konto zostanie aktywowane.';
